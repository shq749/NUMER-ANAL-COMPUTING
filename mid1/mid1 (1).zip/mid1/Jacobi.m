clc; clear; close all
A=zeros(1000);
 for i=1:1000
     A(i,i)=40;
     if i<1000
         A(i+1,i)=-10;
     end
     if i>1
     A(i-1,i)=-10;
     end
 end
 B=ones(1000,1);
 
tol=1e-10; Nmax=1000;

[X,k,residual] = jacobi_result(A, B, tol, Nmax);
X
k
%residual = norm(A*X-B)

function [X_1,k,residual] = jacobi_result(A,B, tol, Nmax)
X_2 = zeros(length(A),1); % k+1 step
X_1 = zeros(length(A),1); % k step
k = 0; % counter
residual = [];
%===k=0======%initial guess
for i =1: length(A)
    X_1(i) = B(i)/A(i,i); 
end
%===iteration======
while (norm(A*X_1-B)>tol && k<Nmax) % |A*X_k-B|>tol 
for i =1: length(A)
    X_2(i) = B(i)/A(i,i);
    for j =1: length(A)
     if j ~= i
         X_2(i) =  X_2(i)-A(i,j)*X_1(j)/A(i,i);
     end
    end
end
X_1 = X_2;
k = k+1;
residual = [residual norm(A*X_1-B)];
end
end
